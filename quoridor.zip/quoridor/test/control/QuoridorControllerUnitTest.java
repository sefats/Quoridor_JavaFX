package control;

public class QuoridorControllerUnitTest {
}
