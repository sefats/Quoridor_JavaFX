package model;

public class QuoridorIntersectionGridUnitTest {
}
