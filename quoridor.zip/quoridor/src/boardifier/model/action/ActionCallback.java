package boardifier.model.action;

@FunctionalInterface
public interface ActionCallback {
    public void execute();
}
