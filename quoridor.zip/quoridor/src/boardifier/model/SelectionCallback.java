package boardifier.model;

@FunctionalInterface
public interface SelectionCallback {
    public void execute();
}
