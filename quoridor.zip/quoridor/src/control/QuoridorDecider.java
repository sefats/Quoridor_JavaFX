package control;

import boardifier.control.Controller;
import boardifier.control.Decider;
import boardifier.model.GameElement;
import boardifier.model.Model;
import boardifier.model.action.ActionList;
import boardifier.model.action.GameAction;
import boardifier.model.action.MoveAction;
import model.QuoridorBoard;
import model.QuoridorWallPot;
import model.QuoridorStageModel;
import model.Wall;

import java.awt.*;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class QuoridorDecider extends Decider {

    private static final Random loto = new Random(Calendar.getInstance().getTimeInMillis());

    public QuoridorDecider(Model model, Controller control) {
        super(model, control);
    }

    @Override
    public ActionList decide() {
        // do a cast get a variable of the real type to get access to the attributes of QuoridorStageModel
        QuoridorStageModel stage = (QuoridorStageModel)model.getGameStage();
        QuoridorBoard board = stage.getBoard(); // get the board
        QuoridorWallPot pot = null; // the pot where to take a wall
        GameElement wall = null; // the wall that is moved
        int rowDest = 0; // the dest. row in board
        int colDest = 0; // the dest. col in board

        if (model.getIdPlayer() == Wall.WALL_BLUE) {
            pot = stage.getBluePot();
        }
        else {
            pot = stage.getRedPot();
        }

        for(int i=0;i<4;i++) {
            Wall p = (Wall)pot.getElement(i,0);
            // if there is a wall in i.
            if (p != null) {
                // get the valid cells
                List<Point> valid = board.computeValidCells(p.getNumber());
                if (valid.size() != 0) {
                    // choose at random one of the valid cells
                    int id = loto.nextInt(valid.size());
                    wall = p;
                    rowDest = valid.get(id).y;
                    colDest = valid.get(id).x;
                    break; // stop the loop
                }
            }
        }

        // create action list. After the last action, it is next player's turn.
        ActionList actions = new ActionList(true);
        // create the move action, without animation => the wall will be put at the center of dest cell
        GameAction move = new MoveAction(model, wall, "quoridorboard", rowDest, colDest);
        actions.addSingleAction(move);
        return actions;
    }
}
