package control;

import boardifier.control.ActionPlayer;
import boardifier.control.Controller;
import boardifier.model.GameElement;
import boardifier.model.GridElement;
import boardifier.model.Model;
import boardifier.model.Player;
import boardifier.model.action.ActionList;
import boardifier.model.action.GameAction;
import boardifier.model.action.MoveAction;
import boardifier.model.action.RemoveAction;
import boardifier.model.animation.AnimationTypes;
import boardifier.view.View;
import model.*;
import view.WallGridLook;
import boardifier.view.GameStageView;
import view.QuoridorStageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class QuoridorController extends Controller {

    BufferedReader consoleIn;
    boolean firstPlayer;

    public QuoridorController(Model model, View view) {
        super(model, view);
        firstPlayer = true;
    }

    /**
     * Defines what to do within the single stage of the single party
     * It is pretty straight forward to write :
     */
    public void stageLoop() {
        consoleIn = new BufferedReader(new InputStreamReader(System.in));
        update();
        while(! model.isEndStage()) {
            nextPlayer();
            update();
        }
        stopStage();
        endGame();
    }

    public void nextPlayer() {
        // for the first player, the id of the player is already set, so do not compute it
        if (!firstPlayer) {
            model.setNextPlayer();
        }
        else {
            firstPlayer = false;
        }
        // get the new player
        Player p = model.getCurrentPlayer();
        if (p.getType() == Player.COMPUTER) {
            System.out.println("COMPUTER PLAYS");
            QuoridorDecider decider = new QuoridorDecider(model,this);
            ActionPlayer play = new ActionPlayer(model, this, decider, null);
            play.start();
        }
        else {
            boolean ok = false;
            while (!ok) {
                System.out.print(p.getName()+ " > ");
                try {
                    String line = consoleIn.readLine();
                    //if (line.length() == 3) {
                        ok = analyseAndPlay(line);
                    //}
                    if (!ok) {
                        System.out.println("incorrect instruction. retry !");
                    }
                }
                catch(IOException e) {}
            }
        }
    }
    private boolean analyseAndPlay(String line) {
        QuoridorStageModel gameStage = (QuoridorStageModel) model.getGameStage();


        int[][] plateau = new int[9][9];
        plateau[gameStage.getRedPawn().getLine()][gameStage.getRedPawn().getCol()] = gameStage.getRedPawn().getPlayerID() + 1;
        plateau[gameStage.getBluePawn().getLine()][gameStage.getBluePawn().getCol()] = gameStage.getBluePawn().getPlayerID() + 1;
        printTab(plateau);
        System.out.println();

        int[][] horizontalWall = new int[8][9];
        for(int i=0; i < horizontalWall.length; i++){
            for(int j=0; j < horizontalWall[0].length; j++){
                if(!gameStage.getHorizontalWallGrid().isEmptyAt(i, j)){
                    horizontalWall[i][j] = 1;
                }
            }
        }
        printTab(horizontalWall);
        System.out.println();

        int[][] verticalWall = new int[9][8];
        for(int i=0; i < verticalWall.length; i++){
            for(int j=0; j < verticalWall[0].length; j++){
                if(!gameStage.getVerticalWallGrid().isEmptyAt(i, j)){
                    verticalWall[i][j] = 1;
                }
            }
        }
        printTab(verticalWall);
        System.out.println();

        int[][] intersection = new int[8][8];
        for(int i=0; i < intersection.length; i++){
            for(int j=0; j < intersection[0].length; j++){
                if(!gameStage.getIntersectionGrid().isEmptyAt(i, j)){
                    intersection[i][j] = 1;
                }
            }
        }
        printTab(intersection);
        System.out.println();



        // get the wall value from the first char
        /*int wallIndex = (int) (line.charAt(0) - '1');
        if ((wallIndex<0)||(wallIndex>3)) return false;
        // get the ccords in the board
        int col = (int) (line.charAt(1) - 'A');
        int row = (int) (line.charAt(2) - '1');
        // check coords validity
        if ((row<0)||(row>2)) return false;
        if ((col<0)||(col>2)) return false;
        // check if the Wall is still in its pot
        GridElement pot = null;
        if (model.getIdPlayer() == 0) {
            pot = gameStage.getBluePot();
        }
        else {
            pot = gameStage.getRedPot();
        }
        if (pot.isEmptyAt(wallIndex,0)) return false;
        GameElement wall = pot.getElement(wallIndex,0);
        // compute valid cells for the chosen wall
        gameStage.getBoard().setValidCells(wallIndex+1);
        if (!gameStage.getBoard().canReachCell(row,col)) return false;*/

        if(!line.equals("no")){
            ActionList actions = new ActionList(true);
            //GameAction move = new MoveAction(model, gameStage.getBluePot().getElement(0,0), "wallgrid", 0, 0);
            GameAction move = new RemoveAction(model, gameStage.getBluePot().getElement(0,0));
            actions.addSingleAction(move);
            QuoridorHorizontalWall newWall = new QuoridorHorizontalWall(QuoridorVerticalWall.WALL_BLUE, gameStage);
            gameStage.getHorizontalWallGrid().putElement(newWall, 0, 0);
            newWall.setVisible(true);
            //QuoridorStageView.setHorizontalWallLook(newWall);
            //GameStageView.addLook(new QuoridorHorizontalWallLook(model.getHorizontalWalls()[i][j]));
            //gameStage.putInGrid(gameStage.getHorizontalWallGrid().getElement(0,0), gameStage.getHorizontalWallGrid(), 0, 0);
            //addLook(new QuoridorHorizontalWallLook(model.getHorizontalWalls()[i][j]));
            //gameStage.putInGrid(gameStage.getBluePot().getElement(0,0), gameStage.getWallGrid(), 0, 0);
            // add the action to the action list.
            actions.addSingleAction(move);
            ActionPlayer play = new ActionPlayer(model, this, actions);
            play.start();
        }
        return true;
    }

    private static void printTab(Object tab, int niveau){
        if(tab instanceof int[]){
            int[] tab1D = (int[])tab;
            System.out.print("[");
            for(int i=0; i < tab1D.length; i++){
                System.out.print(tab1D[i]);
                if (i < tab1D.length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.print("]");
        }else if(tab instanceof double[]){
            double[] tab1D = (double[])tab;
            System.out.print("[");
            for(int i=0; i < tab1D.length; i++){
                System.out.print(tab1D[i]);
                if (i < tab1D.length - 1){
                    System.out.print(", ");
                }
            }
            System.out.print("]");
        }else if(tab instanceof String[]){
            String[] tab1D = (String[])tab;
            System.out.print("[");
            for(int i=0; i < tab1D.length; i++){
                System.out.print(tab1D[i]);
                if(i < tab1D.length - 1){
                    System.out.print(", ");
                }
            }
            System.out.print("]");
        }else{
            Object[] tab2D = (Object[])tab;
            System.out.print("[");
            for(int i=0; i < tab2D.length; i++){
                printTab(tab2D[i], niveau + 1);
                if(i < tab2D.length - 1){
                    System.out.println(", ");
                    for(int j=0; j <= niveau; j++){
                        System.out.print(" ");
                    }
                }
            }
            System.out.print("]");
        }
        if(niveau == 0){
            System.out.println();
        }
    }

    private static void printTab(Object tab){
        printTab(tab, 0);
    }
}
