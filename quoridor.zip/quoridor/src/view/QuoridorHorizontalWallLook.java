package view;

import boardifier.model.GameElement;
import boardifier.view.ConsoleColor;
import boardifier.view.ElementLook;
import model.QuoridorHorizontalWall;
import model.Wall;

public class QuoridorHorizontalWallLook extends ElementLook {

    public QuoridorHorizontalWallLook(GameElement element) {
        super(element, 7, 1);
        QuoridorHorizontalWall wall = (QuoridorHorizontalWall) element;
        String color = "";
        if (wall.getColor() == QuoridorHorizontalWall.WALL_BLUE) {
            color = ConsoleColor.BLUE;
        }else if(wall.getColor() == QuoridorHorizontalWall.WALL_RED){
            color = ConsoleColor.RED;
        }
        for(int i=0; i < shape[0].length; i++){
            shape[0][i] = color + (char)9632 + ConsoleColor.RESET;
        }

    }

    @Override
    public void onLookChange() {
        // do nothing since a wall never change of aspect
    }
}
