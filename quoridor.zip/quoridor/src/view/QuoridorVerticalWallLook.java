package view;

import boardifier.model.GameElement;
import boardifier.view.ConsoleColor;
import boardifier.view.ElementLook;
import model.QuoridorVerticalWall;
import model.Wall;

public class QuoridorVerticalWallLook extends ElementLook {

    public QuoridorVerticalWallLook(GameElement element) {
        super(element, 1, 3);//13
        QuoridorVerticalWall wall = (QuoridorVerticalWall) element;
        String color = "";
        if (wall.getColor() == QuoridorVerticalWall.WALL_BLUE) {
            color = ConsoleColor.BLUE_BACKGROUND;
        }else if(wall.getColor() == QuoridorVerticalWall.WALL_RED){
            color = ConsoleColor.RED_BACKGROUND;
        }
        for(int i=0; i < shape.length; i++){
            shape[i][0] = color + " " + ConsoleColor.RESET;
        }

    }

    @Override
    public void onLookChange() {
        // do nothing since a wall never change of aspect
    }
}
