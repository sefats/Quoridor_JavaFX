package view;

import boardifier.model.GridElement;
import boardifier.view.GridLook;

public class HorizontalWallGridLook extends GridLook {

    public HorizontalWallGridLook(int cellWidth, int cellHeight, GridElement gridElement) {
        super(cellWidth, cellHeight, gridElement, -1, false);
    }

    protected void createShape() {
        GridElement gridElement = (GridElement) element;
        int nbRows = gridElement.getNbRows();
        int nbCols = gridElement.getNbCols();

        for(int i=0;i<shape.length;i++) {
            for(int j=0;j<shape[0].length;j++) {
                shape[i][j] = " ";
            }
        }
    }

    @Override
    public void onLookChange() {
        //nothing
    }
}
