package model;

import boardifier.model.ElementTypes;
import boardifier.model.GameElement;
import boardifier.model.GameStageModel;

public class QuoridorVerticalWall extends GameElement{


    private int color;
    public static int WALL_BLUE = 0;
    public static int WALL_RED = 1;
    public QuoridorVerticalWall(int color, GameStageModel gameStageModel) {
        super(gameStageModel);
        ElementTypes.register("verticalWall", 57);
        type = ElementTypes.getType("verticalWall");
        this.color = color;
    }

    public int getColor() {
        return color;
    }
}
