package model;

import boardifier.model.GameStageModel;
import boardifier.model.StageElementsFactory;
import boardifier.model.TextElement;

public class QuoridorStageFactory extends StageElementsFactory {
    private QuoridorStageModel stageModel;

    public QuoridorStageFactory(GameStageModel gameStageModel) {
        super(gameStageModel);
        stageModel = (QuoridorStageModel) gameStageModel;
    }

    @Override
    public void setup() {
        // create the board
        stageModel.setBoard(new QuoridorBoard(3, 5, stageModel));
        //create the pots
        QuoridorWallPot bluePot = new QuoridorWallPot(3,43, stageModel);
        stageModel.setBluePot(bluePot);
        QuoridorWallPot redPot = new QuoridorWallPot(3,0, stageModel);
        stageModel.setRedPot(redPot);
        QuoridorPawn bluePawn = new QuoridorPawn(0, 4, 8, stageModel);
        stageModel.setBluePawn(bluePawn);
        stageModel.getBoard().putElement(bluePawn, 8, 4);
        QuoridorPawn redPawn = new QuoridorPawn(1, 4, 0, stageModel);
        stageModel.setRedPawn(redPawn);
        stageModel.getBoard().putElement(redPawn, 0, 4);

        // create the walls
        Wall[] blueWalls = new Wall[10];
        for(int i=0;i<10;i++) {
            blueWalls[i] = new Wall(i + 1, Wall.WALL_BLUE, stageModel);
        }
        stageModel.setBlueWalls(blueWalls);
        Wall[] redWalls = new Wall[10];
        for(int i=0;i<10;i++) {
            redWalls[i] = new Wall(i + 1, Wall.WALL_RED, stageModel);
        }
        stageModel.setRedWalls(redWalls);
        // assign walls to their pot : they will be put at the center
        for (int i=0;i<10;i++) {
            bluePot.putElement(blueWalls[i], 0,i);
            redPot.putElement(redWalls[i], 0,i);
        }







        QuoridorHorizontalWallGrid horizontalWallGrid = new QuoridorHorizontalWallGrid(0,7, stageModel);
        stageModel.setHorizontalWallGrid(horizontalWallGrid);
        // create the walls
        QuoridorHorizontalWall[][] horizontalWalls = new QuoridorHorizontalWall[8][9];
        for(int i=0; i<horizontalWalls.length; i++) {
            for(int j=0; j<horizontalWalls[0].length; j++) {
                horizontalWalls[i][j] = new QuoridorHorizontalWall(QuoridorHorizontalWall.WALL_RED, stageModel);
            }
        }
        stageModel.setHorizontalWalls(horizontalWalls);
        for (int i=0;i<horizontalWalls.length;i++) {
            for (int j=0;j<horizontalWalls[0].length;j++) {
                horizontalWallGrid.putElement(horizontalWalls[i][j], i,j);
            }
        }

        QuoridorVerticalWallGrid verticalWallGrid = new QuoridorVerticalWallGrid(7,4, stageModel);
        stageModel.setVerticalWallGrid(verticalWallGrid);
        // create the walls
        QuoridorVerticalWall[][] verticalWalls = new QuoridorVerticalWall[9][8];
        for(int i=0; i<verticalWalls.length; i++) {
            for(int j=0; j<verticalWalls[0].length; j++) {
                verticalWalls[i][j] = new QuoridorVerticalWall(QuoridorVerticalWall.WALL_BLUE, stageModel);
            }
        }
        stageModel.setVerticalWalls(verticalWalls);
        for (int i=0;i<verticalWalls.length;i++) {
            for (int j=0;j<verticalWalls[0].length;j++) {
                verticalWallGrid.putElement(verticalWalls[i][j], i,j);
            }
        }

        QuoridorIntersectionGrid intersectionGrid = new QuoridorIntersectionGrid(7,7, stageModel);
        stageModel.setIntersectionGrid(intersectionGrid);
        // create the walls
        QuoridorIntersection[][] intersections = new QuoridorIntersection[8][8];
        for(int i=0; i<intersections.length; i++) {
            for(int j=0; j<intersections[0].length; j++) {
                intersections[i][j] = new QuoridorIntersection(QuoridorIntersection.INTERSECTION_RED, QuoridorIntersection.horizontal, stageModel);
            }
        }
        stageModel.setIntersections(intersections);
        for (int i=0;i<intersections.length;i++) {
            for (int j=0;j<intersections[0].length;j++) {
                intersectionGrid.putElement(intersections[i][j], i,j);
            }
        }
    }
}
