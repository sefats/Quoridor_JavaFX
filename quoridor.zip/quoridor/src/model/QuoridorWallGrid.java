/*package model;

import boardifier.model.GameStageModel;
import boardifier.model.GridElement;

public class QuoridorWallGrid extends GridElement {
    private int[][] verticalWall;
    private int[][] horizontalWall;
    private int[][][] intersection;

    public QuoridorWallGrid(int x, int y, GameStageModel gameStageModel) {
        super("wallgrid", x, y, 17, 17, gameStageModel);
        this.verticalWall = new int[nbRows][nbCols-1];
        this.horizontalWall = new int[nbRows-1][nbCols];
        this.intersection = new int[2][nbRows-1][nbCols-1];
    }

    public int[][] getHorizontalWall(){
        return this.horizontalWall;
    }
    public int[][] getVerticalWall(){
        return this.verticalWall;
    }
    public int[][][] getIntersection(){
        return this.intersection;
    }
}*/
