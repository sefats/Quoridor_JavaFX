package model;

import boardifier.model.ElementTypes;
import boardifier.model.GameElement;
import boardifier.model.GameStageModel;

public class QuoridorPawn extends GameElement{
    private int playerID;
    private int Col;
    private int Line;

    public QuoridorPawn(int playerID, int Col, int Line, GameStageModel gameStageModel) {
        super(gameStageModel, playerID);
        this.playerID = playerID;
        this.Col = Col;
        this.Line = Line;
        ElementTypes.register("pawn", 55);
        type = ElementTypes.getType("pawn");
    }

    public int getPlayerID(){
        return this.playerID;
    }
    public int getCol(){
        return this.Col;
    }
    public int getLine(){
        return this.Line;
    }
}
