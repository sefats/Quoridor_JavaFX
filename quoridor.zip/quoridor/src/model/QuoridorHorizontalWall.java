package model;

import boardifier.model.ElementTypes;
import boardifier.model.GameElement;
import boardifier.model.GameStageModel;

public class QuoridorHorizontalWall extends GameElement{

    private int color;
    public static int WALL_BLUE = 0;
    public static int WALL_RED = 1;
    public QuoridorHorizontalWall(int color, GameStageModel gameStageModel) {
        super(gameStageModel);
        ElementTypes.register("horizontalWall", 56);
        type = ElementTypes.getType("horizontalWall");
        this.color = color;
    }

    public int getColor() {
        return color;
    }
}
