
package model;

import boardifier.model.GameStageModel;
import boardifier.model.GridElement;

public class QuoridorVerticalWallGrid extends GridElement {

    public QuoridorVerticalWallGrid(int x, int y, GameStageModel gameStageModel) {
        super("horizontalwallgrid", x, y, 9, 8, gameStageModel);
    }
}
