package model;

import boardifier.model.ElementTypes;
import boardifier.model.GameElement;
import boardifier.model.GameStageModel;

public class QuoridorIntersection extends GameElement{

    private int color;
    private int direction;
    public static int INTERSECTION_BLUE = 0;
    public static int INTERSECTION_RED = 1;
    public static int horizontal = 0;
    public static int vertical = 1;

    public QuoridorIntersection(int color, int direction, GameStageModel gameStageModel) {
        super(gameStageModel);
        ElementTypes.register("intersection", 58);
        type = ElementTypes.getType("intersection");
        this.color = color;
        this.direction = direction;
    }

    public int getColor() {
        return color;
    }
    public int getDirection() {
        return direction;
    }
}
