package model;

import boardifier.model.GameStageModel;
import boardifier.model.GridElement;

public class QuoridorWallPot extends GridElement {
    public QuoridorWallPot(int x, int y, GameStageModel gameStageModel) {
        // call the super-constructor to create a 4x1 grid, named "wallpot", and in x,y in space
        super("wallpot", x, y, 1, 10, gameStageModel);
    }
}
