
package model;

import boardifier.model.GameStageModel;
import boardifier.model.GridElement;

public class QuoridorHorizontalWallGrid extends GridElement {

    public QuoridorHorizontalWallGrid(int x, int y, GameStageModel gameStageModel) {
        super("horizontalwallgrid", x, y, 8, 9, gameStageModel);
    }
}
