package model;

import boardifier.model.ElementTypes;
import boardifier.model.GameElement;
import boardifier.model.GameStageModel;
import boardifier.model.animation.AnimationStep;
import boardifier.view.GridGeometry;

public class Wall extends GameElement {

    private int number;
    private int color;
    public static int WALL_BLUE = 0;
    public static int WALL_RED = 1;

    public Wall(int number, int color, GameStageModel gameStageModel) {
        super(gameStageModel);
        // registering element types defined especially for this game
        //ElementTypes.register("wall",50);
        //type = ElementTypes.getType("wall");
        this.number = number;
        this.color = color;
    }

    public int getNumber() {
        return number;
    }

    public int getColor() {
        return color;
    }

}
